class BikeActivity {
}

